package com.jbs.jbsfirebaseapps.common;

/**
 * Created by JBS C022 on 7/6/2016.
 */
public interface AppConstants {

    // Log Tag key
    String LOG_TAG = "JBS_FireApps";

    // Build Type
    String DEBUG_BUILD_TYPE = "debug";

    // Log Type
    int LOGTYPE_VERBOSE = 1;
    int LOGTYPE_DEBUG = 2;
    int LOGTYPE_INFO = 3;
    int LOGTYPE_WARN = 4;
    int LOGTYPE_ERROR = 5;

    // onActivityResult keys
    int REQUESTCODE_MAINACTVTY = 101;
    int REQUESTCODE_SIGN_IN_GOOGLE = 102;

    // Notification Id
    int NOTIFICATION_BUILDER_ID_SINGLE = 1;

    // Remote Config keys
    String BTN_CONFIG_ENABLE = "btn_config_enable";
}
