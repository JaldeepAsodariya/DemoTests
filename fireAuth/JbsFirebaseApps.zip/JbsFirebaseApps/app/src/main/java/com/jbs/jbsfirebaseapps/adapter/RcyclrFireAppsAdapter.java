package com.jbs.jbsfirebaseapps.adapter;

import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.jbs.jbsfirebaseapps.R;
import com.jbs.jbsfirebaseapps.common.GeneralFunctions;
import com.jbs.jbsfirebaseapps.model.MdlFireApps;

import java.util.ArrayList;
import java.util.Random;

/**
 * Created by JBS C022 on 7/6/2016.
 */
public class RcyclrFireAppsAdapter extends RecyclerView.Adapter<RcyclrFireAppsAdapter.ViewHolder> {

    ArrayList<MdlFireApps> arrylstFireApps;
    ArrayList<Integer> arrylstPrmryclr;

    public RcyclrFireAppsAdapter(Context context, ArrayList<MdlFireApps> arrylstFireApps) {
        this.arrylstFireApps = arrylstFireApps;
        this.arrylstPrmryclr = GeneralFunctions.getPrimaryColorArray(context);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View mView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.lo_recyclrvw_item_main, parent,false);

        return new ViewHolder(mView);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        MdlFireApps objMdlFireApps = arrylstFireApps.get(position);

        holder.tvFirstChar.setText(objMdlFireApps.getAppName().substring(0,1));
        holder.tvDemosTitle.setText(objMdlFireApps.getAppName());

        int n = arrylstPrmryclr.size();
        Random rndm_no = new Random();
        n = rndm_no.nextInt(n);
        GradientDrawable bgShape = (GradientDrawable)holder.tvFirstChar.getBackground();
        bgShape.setColor(arrylstPrmryclr.get(n));
    }

    @Override
    public int getItemCount() {
        return arrylstFireApps.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {

        TextView tvFirstChar, tvDemosTitle;
        public ViewHolder(View itemView) {
            super(itemView);
            tvFirstChar = (TextView) itemView.findViewById(R.id.tv_recyclrvw_item_main_firstchr);
            tvDemosTitle = (TextView) itemView.findViewById(R.id.tv_recyclrvw_item_main_title);
        }
    }
}
