package com.jbs.jbsfirebaseapps.model;

/**
 * Created by JBS C022 on 7/6/2016.
 */
public class MdlFireApps {

    String appName;

    public MdlFireApps(String appName) {
        this.appName = appName;
    }

    public String getAppName() {
        return appName;
    }
}
