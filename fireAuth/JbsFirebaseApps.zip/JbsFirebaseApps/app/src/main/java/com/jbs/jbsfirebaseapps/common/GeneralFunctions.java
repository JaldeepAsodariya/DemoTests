package com.jbs.jbsfirebaseapps.common;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.support.v4.content.ContextCompat;
import android.text.TextUtils;

import com.jbs.jbsfirebaseapps.JbsFirebaseApps;
import com.jbs.jbsfirebaseapps.R;
import com.jbs.jbsfirebaseapps.fireauth.FireAuth;
import com.jbs.jbsfirebaseapps.fireconfig.FireConfig;
import com.jbs.jbsfirebaseapps.firedatabase.FireDatabase;
import com.jbs.jbsfirebaseapps.firenotifications.FireNotification;

import java.util.ArrayList;

/**
 * Created by JBS C022 on 7/6/2016.
 */
public class GeneralFunctions {

    /***
     * Get ArrayList of all ColorPrimary
     * ***/
    public static ArrayList<Integer> getPrimaryColorArray(Context context) {

        ArrayList<Integer> arrylstPrmryColor = new ArrayList<>();
        try {
            arrylstPrmryColor.add(ContextCompat.getColor(context, R.color.colorPrimaryRed));
            arrylstPrmryColor.add(ContextCompat.getColor(context, R.color.colorPrimaryPink));
            arrylstPrmryColor.add(ContextCompat.getColor(context, R.color.colorPrimaryPurple));
            arrylstPrmryColor.add(ContextCompat.getColor(context, R.color.colorPrimaryIndigo));
            arrylstPrmryColor.add(ContextCompat.getColor(context, R.color.colorPrimaryBlue));
            arrylstPrmryColor.add(ContextCompat.getColor(context, R.color.colorPrimaryLightBlue));
            arrylstPrmryColor.add(ContextCompat.getColor(context, R.color.colorPrimaryTeal));
            arrylstPrmryColor.add(ContextCompat.getColor(context, R.color.colorPrimaryGreen));
            arrylstPrmryColor.add(ContextCompat.getColor(context, R.color.colorPrimaryDeepOrange));
            arrylstPrmryColor.add(ContextCompat.getColor(context, R.color.colorPrimaryBrown));
            arrylstPrmryColor.add(ContextCompat.getColor(context, R.color.colorPrimaryBlueGrey));
            arrylstPrmryColor.add(ContextCompat.getColor(context, R.color.colorPrimaryBlueMidnight));
        } catch (Resources.NotFoundException e) { e.printStackTrace(); }

        return arrylstPrmryColor;
    }

    /***
     * Get new activity intent as per given position
     * ***/
    public static Intent getIntentGivenPostn(Context context, int slctdPostn) {

        Intent intnActvty;

        switch (slctdPostn) {
            case 0:
                intnActvty = new Intent(context, FireAuth.class);
                break;
            case 1:
                intnActvty = new Intent(context, FireDatabase.class);
                break;
            case 2:
                intnActvty = new Intent(context, FireNotification.class);
                break;
            case 3:
                intnActvty = new Intent(context, FireConfig.class);
                break;
            default:
                intnActvty = new Intent(context, JbsFirebaseApps.class);
        }

        return intnActvty;
    }

    /***
     * Check Email Address Format is valid or not
     * ***/
    public static boolean isvalidEmailFormat(CharSequence target) {
        return !TextUtils.isEmpty(target) && android.util.Patterns.EMAIL_ADDRESS.matcher(target).matches();
    }
}
