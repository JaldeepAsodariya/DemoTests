package com.jbs.jbsfirebaseapps.firedatabase;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.jbs.jbsfirebaseapps.R;
import com.jbs.jbsfirebaseapps.common.AppConstants;
import com.jbs.jbsfirebaseapps.common.LogManager;

/**
 * Created by JBS C022 on 7/6/2016.
 */
public class FireDatabase extends AppCompatActivity {

    TextView tvMessage;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lo_fire_database);

        tvMessage = (TextView) findViewById(R.id.tv_firedb_msg);

        FirebaseDatabase mDatabase = FirebaseDatabase.getInstance();
        DatabaseReference mMessageRef = mDatabase.getReference("message");
        mMessageRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                String msgVal = dataSnapshot.getValue(String.class);
                LogManager.printLog(AppConstants.LOGTYPE_INFO, "Message:" + msgVal);
                tvMessage.setText(msgVal);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });

//        DatabaseReference mUsersRef = mDatabase.getReference("ColUsers");
//        MdlUsers objMdlUsers = new MdlUsers("jdpatel.android@gmail.com");

        /*
        * Method 1
        * Replace/Overwrite current data
        * */
//        mUsersRef.setValue(objMdlUsers);

        /*
        * Method 2
        * Create new node everytime with uniqueId
        * */
//        mUsersRef.push().setValue(objMdlUsers);

        /*
        * Method 3
        * Create new node everytime with given uniqueId
        * */
        /*String mUniqueId = mUsersRef.push().getKey();
        LogManager.printLog(AppConstants.LOGTYPE_INFO, "UniqueId: " + mUniqueId);
        mUsersRef.child(mUniqueId).setValue(objMdlUsers);*/

        /*
        * Update single child
        * Update child value by given uniqueId
        * */
//        mUsersRef.child("-KM3coAtzEJS3AbqHifa").child("displayName").setValue("Jaldeep");
    }
}
