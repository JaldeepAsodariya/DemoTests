package com.jbs.jbsfirebaseapps.services;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.media.RingtoneManager;
import android.net.Uri;
import android.support.v4.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.jbs.jbsfirebaseapps.R;
import com.jbs.jbsfirebaseapps.common.AppConstants;
import com.jbs.jbsfirebaseapps.common.LogManager;
import com.jbs.jbsfirebaseapps.firenotifications.FireNotification;

/**
 * Created by JBS C022 on 7/6/2016.
 */
public class FireMessagingService  extends FirebaseMessagingService implements AppConstants {

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        // TODO(developer): Handle FCM messages here.

        LogManager.printLog(LOGTYPE_INFO, "From: " + remoteMessage.getFrom());
        LogManager.printLog(LOGTYPE_INFO, "Notification Message Body: " + remoteMessage.getNotification().getBody());

        // Check if message contains a data payload.
        if (remoteMessage.getData().size() > 0) {
            LogManager.printLog(LOGTYPE_DEBUG, "Message data payload: " + remoteMessage.getData());
        }

        // Check if message contains a notification payload.
        if (remoteMessage.getNotification() != null) {
            LogManager.printLog(LOGTYPE_DEBUG, "Message Notification Body: " + remoteMessage.getNotification().getBody());
        }

        // Build notification
        sendNotification(remoteMessage.getNotification().getBody());
    }

    private void sendNotification(String messageBody) {
        Intent intent = new Intent(this, FireNotification.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, REQUESTCODE_MAINACTVTY, intent,
                PendingIntent.FLAG_ONE_SHOT);

        Uri defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(this)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("FCM Message")
                .setContentText(messageBody)
                .setAutoCancel(true)
                .setSound(defaultSoundUri)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(messageBody))
                .setContentIntent(pendingIntent);

        NotificationManager notificationManager =
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        notificationManager.notify(NOTIFICATION_BUILDER_ID_SINGLE, notificationBuilder.build());
    }
}
