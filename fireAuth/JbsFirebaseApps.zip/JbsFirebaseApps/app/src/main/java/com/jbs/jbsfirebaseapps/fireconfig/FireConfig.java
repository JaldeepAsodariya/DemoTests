package com.jbs.jbsfirebaseapps.fireconfig;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings;
import com.jbs.jbsfirebaseapps.BuildConfig;
import com.jbs.jbsfirebaseapps.R;
import com.jbs.jbsfirebaseapps.common.AppConstants;

/**
 * Created by JBS C022 on 2/27/2017.
 */

public class FireConfig extends AppCompatActivity {

    CoordinatorLayout mCrdntrlyot;
    Button mBtnConfigStatus;
    FirebaseRemoteConfig mFireRemoteConfig;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lo_fire_config);

        mCrdntrlyot = (CoordinatorLayout) findViewById(R.id.cordntrlyot_fireconfig);
        mBtnConfigStatus = (Button) findViewById(R.id.btn_fireconfig_configstatus);
        mBtnConfigStatus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fetchConfigStatus();
            }
        });

        mFireRemoteConfig = FirebaseRemoteConfig.getInstance();
        FirebaseRemoteConfigSettings mConfigSettings = new FirebaseRemoteConfigSettings.Builder()
                .setDeveloperModeEnabled(BuildConfig.DEBUG)
                .build();
        mFireRemoteConfig.setConfigSettings(mConfigSettings);
        mFireRemoteConfig.setDefaults(R.xml.remote_config_defaults);

        fetchConfigStatus();
    }

    private void fetchConfigStatus() {

        long cacheExpiration = 3600;
        if (mFireRemoteConfig.getInfo().getConfigSettings().isDeveloperModeEnabled()) {
            cacheExpiration = 0;
        }

        mFireRemoteConfig.fetch(cacheExpiration).addOnCompleteListener(this, new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {

                if (task.isSuccessful()) {

                    Snackbar.make(mCrdntrlyot, "Fetch Succeeded", Snackbar.LENGTH_SHORT).show();
                    mFireRemoteConfig.activateFetched();
                } else
                    Snackbar.make(mCrdntrlyot, "Fetch Failed", Snackbar.LENGTH_SHORT).show();

                updateUI();
            }
        });
    }

    private void updateUI() {

        if(mFireRemoteConfig.getBoolean(AppConstants.BTN_CONFIG_ENABLE))
            mBtnConfigStatus.setText(getString(R.string.config_status, "true"));
        else
            mBtnConfigStatus.setText(getString(R.string.config_status, "false"));

        mBtnConfigStatus.setEnabled(mFireRemoteConfig.getBoolean(AppConstants.BTN_CONFIG_ENABLE));
    }
}
