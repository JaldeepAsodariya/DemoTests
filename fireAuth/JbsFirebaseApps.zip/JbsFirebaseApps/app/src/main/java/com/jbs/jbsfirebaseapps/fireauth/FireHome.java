package com.jbs.jbsfirebaseapps.fireauth;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.view.LayoutInflaterCompat;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.jbs.jbsfirebaseapps.R;
import com.mikepenz.iconics.context.IconicsLayoutInflater;
import com.squareup.picasso.Picasso;

/**
 * Created by JBS C022 on 9/30/2016.
 */

public class FireHome extends AppCompatActivity {

    ImageView mImgvwProfile;
    TextView mTvDisplayName, mTvEmail;
    FirebaseAuth mFireAuth;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        LayoutInflaterCompat.setFactory(getLayoutInflater(), new IconicsLayoutInflater(getDelegate()));
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lo_fire_auth_home);

        mImgvwProfile = (ImageView) findViewById(R.id.imgvw_fireauth_home_profile);
        mTvDisplayName = (TextView) findViewById(R.id.tv_fireauth_home_displayname);
        mTvEmail = (TextView) findViewById(R.id.tv_fireauth_home_email);

        mFireAuth = FirebaseAuth.getInstance();
        FirebaseUser fireUser = mFireAuth.getCurrentUser();
        if (fireUser != null) {

            Picasso.with(this)
                    .load(fireUser.getPhotoUrl())
                    .placeholder(R.drawable.img_firebase_logo)
                    .into(mImgvwProfile);
            mTvDisplayName.setText(fireUser.getDisplayName());
            mTvEmail.setText(fireUser.getEmail());
        }
    }
}
