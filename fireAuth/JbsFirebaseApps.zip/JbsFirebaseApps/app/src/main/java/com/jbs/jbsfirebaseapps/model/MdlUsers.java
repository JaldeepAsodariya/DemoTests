package com.jbs.jbsfirebaseapps.model;

import com.google.firebase.database.IgnoreExtraProperties;

/**
 * Created by JBS C022 on 7/7/2016.
 */
@IgnoreExtraProperties
public class MdlUsers {

    private String displayName, email, photoUrl, uId;

    public MdlUsers() {}

    public MdlUsers(String email) {
        this.email = email;
    }

    public MdlUsers(String displayName, String email, String photoUrl) {
        this.displayName = displayName;
        this.email = email;
        this.photoUrl = photoUrl;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhotoUrl() {
        return photoUrl;
    }

    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl;
    }

    public String getuId() {
        return uId;
    }

    public void setuId(String uId) {
        this.uId = uId;
    }
}
