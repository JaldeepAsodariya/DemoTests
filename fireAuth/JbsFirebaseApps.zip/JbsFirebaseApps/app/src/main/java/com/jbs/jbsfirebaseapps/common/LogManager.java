package com.jbs.jbsfirebaseapps.common;

import android.util.Log;

import com.jbs.jbsfirebaseapps.BuildConfig;

/**
 * Created by JBS C022 on 7/6/2016.
 */
public class LogManager implements AppConstants {

    private static boolean LOGGING_ENABLED = false;

    static {
        if (BuildConfig.BUILD_TYPE.equals(DEBUG_BUILD_TYPE)) {
            LOGGING_ENABLED = true;
        }
    }

    public static void printLog(int logType, String logMessage) {

        switch (logType) {
            case LOGTYPE_VERBOSE:
                if (LOGGING_ENABLED) {
                    if (Log.isLoggable(LOG_TAG, Log.VERBOSE))
                        Log.v(LOG_TAG, logMessage);
                }
                break;
            case LOGTYPE_DEBUG:
                if (LOGGING_ENABLED) {
                    if (Log.isLoggable(LOG_TAG, Log.DEBUG))
                        Log.d(LOG_TAG, logMessage);
                }
                break;
            case LOGTYPE_INFO:
                if (LOGGING_ENABLED)
                    Log.i(LOG_TAG, logMessage);
                break;
            case LOGTYPE_WARN:
                if (LOGGING_ENABLED)
                    Log.w(LOG_TAG, logMessage);
                break;
            case LOGTYPE_ERROR:
                if (LOGGING_ENABLED)
                    Log.e(LOG_TAG, logMessage);
                break;

            default:
                if (LOGGING_ENABLED)
                    Log.i(LOG_TAG, logMessage);
                break;
        }
    }
}
