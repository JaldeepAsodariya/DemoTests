package com.jbs.jbsfirebaseapps.firenotifications;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessaging;
import com.jbs.jbsfirebaseapps.R;
import com.jbs.jbsfirebaseapps.common.AppConstants;
import com.jbs.jbsfirebaseapps.common.LogManager;

/**
 * Created by JBS C022 on 7/6/2016.
 */
public class FireNotification extends AppCompatActivity implements AppConstants {

    Button mBtnSubscribe, mBtnLogToken;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lo_fire_notification);

        mBtnSubscribe = (Button) findViewById(R.id.btn_firenotfctn_subscribe);
        mBtnLogToken = (Button) findViewById(R.id.btn_firenotfctn_logToken);

        if (getIntent().getExtras() != null) {
            for (String key : getIntent().getExtras().keySet()) {
                String value = getIntent().getExtras().getString(key);
                LogManager.printLog(LOGTYPE_INFO, "Key: " + key + " Value: " + value);
            }
        }

//        FirebaseCrash.report(new Exception("My first Android non-fatal error"));

        mBtnSubscribe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseMessaging.getInstance().subscribeToTopic("news");
                LogManager.printLog(LOGTYPE_INFO, "Subscribed to news topic");
            }
        });

        mBtnLogToken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LogManager.printLog(LOGTYPE_INFO, "InstanceID token: " + FirebaseInstanceId.getInstance().getToken());
            }
        });
    }
}
