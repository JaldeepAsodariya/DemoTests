package com.jbs.jbsfirebaseapps.services;

import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;
import com.jbs.jbsfirebaseapps.common.AppConstants;
import com.jbs.jbsfirebaseapps.common.LogManager;

/**
 * Created by JBS C022 on 7/6/2016.
 */
public class FireInstanceIDService  extends FirebaseInstanceIdService implements AppConstants {

    @Override
    public void onTokenRefresh() {

        // Get updated InstanceID token.
        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        LogManager.printLog(LOGTYPE_INFO, "Refreshed token: " + refreshedToken);

        // TODO: Implement this method to send any registration to your app's servers.
//        sendRegistrationToServer(refreshedToken);
    }

    /*private void sendRegistrationToServer(String token) {
        // Add custom implementation, as needed.
    }*/
}
