package com.jbs.jbsfirebaseapps;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;

import com.google.firebase.database.FirebaseDatabase;
import com.jbs.jbsfirebaseapps.adapter.RcyclrFireAppsAdapter;
import com.jbs.jbsfirebaseapps.common.GeneralFunctions;
import com.jbs.jbsfirebaseapps.model.MdlFireApps;

import java.util.ArrayList;

public class JbsFirebaseApps extends AppCompatActivity {

    RecyclerView mRecylcrvw;
    RecyclerView.Adapter mAdaptper;
    ArrayList<MdlFireApps> mArrylstMdlDemoAppses;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.lo_jbs_firebase_apps);

        // Enabling Offline
        FirebaseDatabase.getInstance().setPersistenceEnabled(true);

        mRecylcrvw = (RecyclerView) findViewById(R.id.recylrvw_main_demoslist);

        mRecylcrvw.setHasFixedSize(true);
        mRecylcrvw.setLayoutManager(new LinearLayoutManager(this));

        mArrylstMdlDemoAppses = new ArrayList<>();
        mArrylstMdlDemoAppses.add(new MdlFireApps("Auth"));
        mArrylstMdlDemoAppses.add(new MdlFireApps("Database"));
        mArrylstMdlDemoAppses.add(new MdlFireApps("Notification"));
        mArrylstMdlDemoAppses.add(new MdlFireApps("Remote Config"));

        mAdaptper = new RcyclrFireAppsAdapter(this, mArrylstMdlDemoAppses);
        mRecylcrvw.setAdapter(mAdaptper);

        final GestureDetector mGestureDetector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {

            @Override public boolean onSingleTapUp(MotionEvent e) { return true; }
        });
        mRecylcrvw.addOnItemTouchListener(new RecyclerView.OnItemTouchListener() {
            @Override
            public boolean onInterceptTouchEvent(RecyclerView recyclerView, MotionEvent motionEvent) {

                View child = recyclerView.findChildViewUnder(motionEvent.getX(), motionEvent.getY());

                if (child != null && mGestureDetector.onTouchEvent(motionEvent)) {

                    int slctdPosition = recyclerView.getChildLayoutPosition(child);
                    startActivity(GeneralFunctions.getIntentGivenPostn(JbsFirebaseApps.this, slctdPosition));

                    return true;
                }
                return false;
            }

            @Override
            public void onTouchEvent(RecyclerView recyclerView, MotionEvent motionEvent) {}

            @Override
            public void onRequestDisallowInterceptTouchEvent(boolean disallowIntercept) {}
        });
    }
}
